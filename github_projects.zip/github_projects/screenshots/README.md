# Screenshots

Folder này chứa các ảnh minh họa cho dự án:

- `game-interface.png` - Giao diện chính của game
- `admin-dashboard.png` - Bảng điều khiển admin  
- `leaderboard.png` - Bảng xếp hạng

## Cách thêm screenshots:

1. Chụp ảnh màn hình của game
2. Lưu với tên file tương ứng
3. Upload vào thư mục này
4. Cập nhật README.md chính để hiển thị ảnh

## Kích thước khuyến nghị:
- Chiều rộng: 800-1200px
- Format: PNG hoặc JPG
- Chất lượng: High resolution
